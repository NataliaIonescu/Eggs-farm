package eggsFarm;

import java.io.Serializable;

public class Egg  implements Serializable{

    int serial;
    int henSerial;

    public Egg (int henSerial, int serial) {
        this.henSerial = henSerial;
        this.serial = serial;
    }
    
}
