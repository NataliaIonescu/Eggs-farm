package eggsFarm;

import java.util.Random;

public class Hen  extends Thread {
	
    int x;
    int y;
    private Farm farm =null;
    boolean requiredEggs;
    private final int serial;
    int[] MoveDirection =  null;  // matrix having 4 directions, which will be random ( using mixDirections function)
    Hen (int serial){
        this.serial = serial;
        requiredEggs = true;
        MoveDirection = new int[4];
        MoveDirection[0] = 0;
        MoveDirection[1] = 1;
        MoveDirection[2] = 2;
        MoveDirection[3] = 3;

    }
    public void Assign(Farm farm,int x, int y) {
        this.farm = farm;	// assign hen to the farm
        this.x = x;
        this.y = y;

    }
    public void run(){
        boolean moved;

        while(requiredEggs) {
            moved = tryToMove();  // hen tries to move
            if(moved){
                Egg egg = new Egg(farm.getID(),this.serial);
                farm.giveEgg(egg);		// if the hen moved, it lays an egg and lets the employee take the egg for the farm
                System.out.println("Egg was laid");

                if(moved) {
                    try {
                        sleep(30*10); // rest time
                    } catch (InterruptedException e) {		
                        e.printStackTrace();
                    }
                }
                else {
                    try {	
                        sleep((int) (Math.random() * (50-10) + 10)); // wait time when hen cannot move in any direction
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private boolean tryToMove() {
        mixDirections();  // random directions in matrix
        boolean moved = false;
        try{
            farm.RequestMove(); // farm is locked when a hen wants to move
            for(int i = 0 ; i < 4 ; i++) {  // hen tries to move on all 4 directions
                if(farm.RequestMoveDirection(x,y,MoveDirection[i])) {
                    Move(MoveDirection[i]);
                    moved = true;
                    System.out.println("Hen "+ serial+ ", on position " + this.x + ", " + this.y + " laid another egg");
                    break;
                }
            }
        }
        finally {
            farm.MoveFinished(); // after the hen moved, the farm is unlocked
        }
        return moved;
    }

    private void Move(int i) { // update the coordinates based on the direction the hen moves
        switch(i) {
            case 0:
                x++;
                break;
            case 1:
                x--;
                break;
            case 2:
                y++;
                break;
            case 3:
                y--;
                break;
        }
    }

    public int GetPosition() {
        return x*1000+y; // a way that gives both coordinates at the same time; the leftmost numbers are x and the rightmost y
    }

    public void opresteProductia() { // update the flag to stop production
        requiredEggs = false;
        System.out.println("Hen " + serial + " stopped");

    }

    private void mixDirections() { // function that randomly mixes the direction of the matrix
        Random rand = new Random();
        for (int i = 0; i < MoveDirection.length; i++) {
            int randomIndexToSwap = rand.nextInt(MoveDirection.length);
            int temp = MoveDirection[randomIndexToSwap];
            MoveDirection[randomIndexToSwap] = MoveDirection[i];
            MoveDirection[i] = temp;
        }
    }

}
