package eggsFarm;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.*;
import java.util.Vector;

public class Headquarter  extends Thread {

	Vector<Farm> farms = new Vector<Farm>();
    Vector<Employee> employees = new Vector<Employee>();
    Vector<Egg> eggs = new Vector<Egg>();
    ServerSocket socket = null;
    int activeFarms;
    static int noHens = 0;
    

    Headquarter() {

        activeFarms = 3;	// there are created farms
        for(int i=0; i<activeFarms; i++) {
            farms.add(new Farm(this,i));
        }
        openTransportLine();// opens TCP/IP

        for(int i=0; i<10; i++) {	// maximum number of employees
            employees.add(new Employee(this,farms));
            System.out.println("Employee " + i + " was called" );
        }
       
    }

    public void run() {
        while(farmsRunning()) {
            addHens();		/* The hens are spawning randomly in each farm at a random place, at a random time t,
            						where 500 ≤ t ≤ 1000 (milliseconds). */
            try {
                Thread.sleep((int) (Math.random() * (1000-500) + 500));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("All farms have finished work, they have "+ eggs.size() +" eggs");
        try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void openTransportLine() {
        try {
            socket = new ServerSocket(7777);
            new Thread(() -> {	// a new thread created for the transport line
                accepteggs();
            }).start();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void accepteggs() {
        while(farmsRunning()) { 
            Socket transport_employees = null;
            try {
                transport_employees = socket.accept();	// the employees try to make a connection and take eggs from the hens
                InputStream inputStream = transport_employees.getInputStream();
                ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);

                try {
                    System.out.println("The egg was received"); // confirmation that the egg has been received
                    Egg egg = (Egg) objectInputStream.readObject();
                    eggs.add(egg);
                } catch (ClassNotFoundException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if(transport_employees != null)	// if connection had been made closes socket
                    transport_employees.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private synchronized void addHens() {
        for(int i=0; i<farms.size(); i++) {	// tries to add a hen to each farm
            if(farms.elementAt(i).needsHen())
                farms.elementAt(i).addHen(new Hen(noHens++));
        }

    }

    public void announce(Farm F) {	// announce to employees that Farm F has eggs ready for transport
        for(int i=0;i<employees.size();i++) {
            if(employees.elementAt(i).announce(F)) {
            }
        }
    }

    public synchronized void announceStop(Farm Farm) {	// function called in Farm by Headquarter John to stop the production
        activeFarms--;
    }

    public boolean farmsRunning() {	// shows if there are farms running(active)
        if(activeFarms == 0)
            return false;
        return true;
    }

}
