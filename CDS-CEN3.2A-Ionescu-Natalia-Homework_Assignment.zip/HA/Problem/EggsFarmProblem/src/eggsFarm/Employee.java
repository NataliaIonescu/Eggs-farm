package eggsFarm;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Vector;

public class Employee extends Thread {

    Headquarter headquarter = null;
    private Vector<Farm> farms = null;
    private volatile Farm source_Farm = null; // is declared volatile to ensure that the value is up to date
    Socket socket = null;

    public Employee (Headquarter headquarter, Vector<Farm> farms) {
        this.headquarter = headquarter;
        this.farms  = farms; // has access to farms to read the data

        this.start();
    }

    public void run() {
        while(headquarter.farmsRunning()) {
            readData();								// read the data from farms
            if(getSourceFarm() != null) {		// when a farm is assigned to take an egg, the employee tries to finish his job
                transportEggs();
            }
            setSource(null); // reset source_Farm
        }
    }

    private void transportEggs() {
        if(source_Farm.RequestTransportAcces()) {  // employee receives access
            source_Farm.RequestMove();		// the farm is locked
            Vector<Egg> V = source_Farm.getEggList(); // employee receives egg list
            if(V.isEmpty()) {		// if there are no more eggs,  the farm is unlocked and released
                source_Farm.MoveFinished();
                source_Farm.TransportFinished();
                return;
            }
            Egg egg = V.remove(0); // employee puts the first egg on the list, then unlock and release
            source_Farm.MoveFinished();
            source_Farm.TransportFinished();

            try {
                socket = new Socket("localhost", 7777);
                OutputStream outputStream = socket.getOutputStream();  // takes the output stream directly from the socket
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
                objectOutputStream.writeObject(egg);	 // it is created an object output stream from the output stream to be able to send an object through it
                socket.close();

            } catch (IOException e) {
                //e.printStackTrace();
            }

            System.out.println("The egg was delivered by the employee to the farm headquarter");
        }

    }

    private void readData() { // read information from the farms and waits after every reading
        for(int i=0; i<farms.size();i++) {
            farms.elementAt(i).getNoEggs();
            farms.elementAt(i).getEggList();
            try {
                sleep((int) (Math.random() * (30-10) + 10)); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

    public boolean announce(Farm F) {  // if a hen does not have a transport source, then it is assigned a source
        if(source_Farm == null) {	
            setSource(F);
            return true;
        }
        return false;
    }

    private synchronized void setSource(Farm F) {
        source_Farm = F;	// sets the source to farm
    }

    private Farm getSourceFarm() {
        return source_Farm;
    }

}
