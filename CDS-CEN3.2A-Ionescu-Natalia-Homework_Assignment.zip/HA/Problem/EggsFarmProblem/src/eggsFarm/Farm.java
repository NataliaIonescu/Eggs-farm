package eggsFarm;

import java.util.Vector;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.ReentrantLock;

public class Farm extends Thread{
	
	 ReentrantLock move_lock = new ReentrantLock(true);

	    Headquarter headquarter = null;
	    Vector<Hen> hens = new Vector<Hen>();
	    Vector<Egg> eggs = new Vector<Egg>();
	    Semaphore semaphore = new Semaphore(10,true);
	    int matrixSize = 0;
	    int[][] matrix;
	    int id;
	    int noEggsCreated = 0;
	    int noRequiredEggs;



	    public Farm (Headquarter headquarter,int id) {
	        this.headquarter = headquarter; // initialization
	        matrixSize = (int) (Math.random() * (500-100) + 100);
	        matrix = new int[matrixSize][matrixSize];
	        this.id = id;
	        noRequiredEggs = (int) (Math.random() * (100-25) + 25); // number of eggs required  per farm

	        new Thread(() -> { /* Every few seconds the farm monitoring system will request the position of the hens
	        							inside the farm */
	            RequestPositions();
	        }).start();

	        this.start();
	    }

	    public void run() {
	        while(FarmRunning()) { // announce if there are enough eggs to be transported
	            if(eggs.size() > 9) {
	                headquarter.announce(this);
	            }
	        }
	        stopHens(); // enough eggs were laid, the hens can rest

	        while(!eggs.isEmpty()) {	// announce that there are enough eggs to be transported and the hens are resting
	            headquarter.announce(this);
	        }

	        headquarter.announceStop(this);	// farm f has finished the work
	        System.out.println("Farm "+id+" has finished collecting the required eggs");
	    }



	    public void addHen(Hen production_Hen) { // creates the hens and assigns them to random farms
	        int x; // the x, y coordinates for the matrix
	        int y;
	        move_lock.lock(); // lock until the hen is placed
	        do { // generate random positions for hen
	            x = (int) ((Math.random() * (matrixSize)) + 0);
	            y = (int) ((Math.random() * (matrixSize)) + 0);
	        } while (matrix[x][y] != 0);
	        matrix[x][y] = 1;
	        move_lock.unlock();
	        production_Hen.Assign(this,x,y);
	        hens.add(production_Hen);
	        production_Hen.start();
	        System.out.println("Hen " + id + " lays eggs on the position " +  x + ", " + y);
	    }

	    public void RequestMove() {
	        move_lock.lock();
	    }

	    public boolean RequestMoveDirection(int x,int y,int i) {
	        int val = -1; // the function checks if the direction requested by the hen is free to be occupied
	        switch(i) {
	            case 0:
	                if(x+1 >= matrixSize)
	                    break;
	                val = matrix[x+1][y];
	                break;
	            case 1:						
	                if(x-1 < 0)				
	                    break;				
	                val = matrix[x-1][y];			
	                break;
	            case 2:							
	                if(y+1 >= matrixSize)		
	                    break;					
	                val = matrix[x][y+1];
	                break;
	            case 3:
	                if(y-1 < 0)
	                    break;
	                val = matrix[x][y-1];
	                break;
	        }
	        // check if the direction is available and move the hen
	        if(val == 0) {
	            switch(i) {
	                case 0:
	                    matrix[x+1][y]++;
	                    break;
	                case 1:
	                    matrix[x-1][y]++;
	                    break;
	                case 2:
	                    matrix[x][y+1]++;
	                    break;
	                case 3:
	                    matrix[x][y-1]++;
	                    break;
	            }
	            matrix[x][y]--;
	            return true;
	        }
	        return false;
	    }

	    public void MoveFinished() {

	        move_lock.unlock();

	    }

	    public void giveEgg(Egg egg) { // the hen lets the employee take the egg for the farm
	        move_lock.lock();
	        eggs.add(egg);
	        noEggsCreated++;
	        move_lock.unlock();
	        System.out.println("Egg laid at farm "+id);  // an egg was laid at a farm
	    }

	    public void RequestPositions() {  // function that requests the position
	        while(FarmRunning()) {
	            try{
	                move_lock.lock();

	                for(int i = 0; i< hens.size(); i++) {
	                    hens.elementAt(i).GetPosition();
	                }
	            }
	            finally {
	                move_lock.unlock();
	            }
	            try {	// sleep for a random time
	                sleep((int) (Math.random() * (5000-1000) + 1000)); // random time to be able to check the position
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }
	    }

	    private boolean FarmRunning() {
	        return noRequiredEggs > noEggsCreated; // check if farm works well
	    }

	    public boolean needsHen() {  // check if the farm needs more hens
	        return hens.size() < matrixSize / 2 && FarmRunning();	// check if number of hens is < N/2 and  if the farm needs more hens
	    }

	    public int getID() {
	        return id;		// id for a farm 
	    }

	    public int getNoEggs() { // used by employees
	        return eggs.size();
	    }

	    public Vector<Egg> getEggList() {// used by employees
	        return eggs;
	    }

	    private void stopHens() { // makes the hens to stop
	        for(int i=0; i<hens.size(); i++){
	            hens.elementAt(i).opresteProductia();
	        }
	    }
	    public boolean RequestTransportAcces() { // used by employees
	        return semaphore.tryAcquire();
	    }

	    public void TransportFinished() {// used by employees
	        semaphore.release();
	    }

}
