package eggsFarm;

public class Main {
	
    public static void main(String[] args) {

        Headquarter headquarter = new Headquarter();
        headquarter.start();

    }

}
